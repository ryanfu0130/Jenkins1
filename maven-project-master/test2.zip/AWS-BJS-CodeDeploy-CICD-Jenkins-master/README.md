# AWS-BJS-CodeDeploy-CICD-Jenkins
## AWS-BJS-CodeDeploy-CICD-Jenkins

https://aws.amazon.com/cn/blogs/china/aws-devops-jenkins-and-codedeploy/

[AWS-BJS-CodeDeploy-CICD-Jenkins 操作手册](AWS-BJS-CodeDeploy-CICD-Jenkins.md) 